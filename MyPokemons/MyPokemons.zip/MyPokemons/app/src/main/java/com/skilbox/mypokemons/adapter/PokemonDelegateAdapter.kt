package com.skilbox.mypokemons.adapter

import android.view.View
import android.view.ViewGroup
import com.hannesdorfmann.adapterdelegates4.AbsListItemAdapterDelegate
import com.skilbox.flowsearchmovie.adapter.inflate
import com.skilbox.mypokemons.R
import com.skilbox.mypokemons.data.Pokemon

class PokemonDelegateAdapter():
    AbsListItemAdapterDelegate<Pokemon, Pokemon, PokemonDelegateAdapter.PokemonViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup): PokemonViewHolder {
        return PokemonViewHolder(parent.inflate(R.layout.pokemon_item_list))
    }

    class PokemonViewHolder(view: View) : BaseHolder(view) {

        fun bind(pokemon: Pokemon) {
            bindMainInfo(id = pokemon.id,)
        }
        override val containerView: View
            get() = itemView
    }

    override fun isForViewType(
        item: Pokemon,
        items: MutableList<Pokemon>,
        position: Int
    ): Boolean {
        return true
    }

    override fun onBindViewHolder(
        item: Pokemon,
        holder: PokemonViewHolder,
        payloads: MutableList<Any>
    ) {
        holder.bind(item)
    }
}