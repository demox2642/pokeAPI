package com.skilbox.mypokemons.data

data class Sprites(
    val front_default: String
)
