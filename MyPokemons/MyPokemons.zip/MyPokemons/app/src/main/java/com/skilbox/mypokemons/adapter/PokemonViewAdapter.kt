package com.skilbox.mypokemons.adapter

import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.hannesdorfmann.adapterdelegates4.AsyncListDifferDelegationAdapter
import com.skilbox.mypokemons.data.Pokemon
import com.skilbox.mypokemons.placeholder.PlaceholderContent.PlaceholderItem


class PokemonViewAdapter : AsyncListDifferDelegationAdapter<Pokemon>(MovieDiffUtilCallBack()) {

    init {
        delegatesManager.addDelegate(PokemonDelegateAdapter())
    }

    class MovieDiffUtilCallBack : DiffUtil.ItemCallback<Pokemon>() {
        override fun areItemsTheSame(oldItem: Pokemon, newItem: Pokemon): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: Pokemon, newItem: Pokemon): Boolean {
            return oldItem == newItem
        }
    }
}
