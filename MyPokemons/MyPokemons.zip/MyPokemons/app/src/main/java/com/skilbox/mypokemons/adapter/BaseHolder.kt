package com.skilbox.mypokemons.adapter

import android.view.View
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.extensions.LayoutContainer
import kotlinx.android.synthetic.main.pokemon_item.*
import kotlinx.android.synthetic.main.pokemon_item.view.*

abstract class BaseHolder(
    view: View
    //,private val onItemCkick: (item: Int) -> Unit
) : RecyclerView.ViewHolder(view), LayoutContainer {


    protected fun bindMainInfo(
        id: Int
    ) {
        itemView.setOnClickListener {
          //  onItemCkick(id)
        }

        itemView.movie_id.text = id.toString()

//        movie_type.text = type
//
//        Glide.with(movie_image)
//            .load(poster)
//            .placeholder(R.drawable.load_imege)
//            .into(itemView.movie_image)
//            .view
    }
}
