package com.skilbox.mypokemons

import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController

class SplashScreenFragment : Fragment() {


    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        Log.e("SplashScreenFragment","onActivityCreated")
        Handler().postDelayed({
            findNavController().navigate(R.id.action_splashScreenFragment_to_mainFragment)
        }, 2000)
    }

}
