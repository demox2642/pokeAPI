package com.skilbox.mypokemons.plagin.viewmodel

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.skilbox.mypokemons.data.Pokemon
import com.skilbox.mypokemons.data.Sprites

class PokemonViewModel : ViewModel() {

    private val pokemonListLiveData = MutableLiveData<List<Pokemon>>()
    val pokemonList: LiveData<List<Pokemon>>
        get() = pokemonListLiveData

    private val newList = listOf(
        Pokemon(id = 39, name = "jigglypuff", weight = 55, height = 5, sprites = Sprites(front_default = "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/39.png")),
        Pokemon(id = 43, name = "oddish", weight = 54, height = 5, sprites = Sprites(front_default = "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/43.png")),
        Pokemon(id = 42, name = "golbat", weight = 550, height = 16, sprites = Sprites(front_default = "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/42.png")),
        Pokemon(id = 44, name = "gloom", weight = 86, height = 8, sprites = Sprites(front_default = "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/44.png")),
        Pokemon(id = 45, name = "vileplume", weight = 186, height = 12, sprites = Sprites(front_default = "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/45.png"))
    )

    fun gelAllPokemons() {

        pokemonListLiveData.postValue(newList)
        Log.e("VM", "${pokemonList.value }")
    }
}
